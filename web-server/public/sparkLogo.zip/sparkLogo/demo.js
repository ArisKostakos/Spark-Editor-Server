var demo = {
    constructor: CreateCSGTestScene,
    onload: function () {
    }
};